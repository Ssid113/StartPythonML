def f1():
    return 1
