def f2():
    return 2
